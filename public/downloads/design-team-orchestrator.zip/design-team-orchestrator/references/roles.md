# Design team roles

Choose roles by the decision the brief needs. Spawn the smallest effective team.

## Product strategist

Owns problem framing, audience, value proposition, success criteria, scope, and product tradeoffs.

Use when the request is ambiguous, strategic, or needs prioritization.

## UX researcher

Owns evidence review, user needs, jobs, assumptions, research questions, and validation design.

Use when source material, customer feedback, or uncertainty about users matters. Do not fabricate interviews or findings.

## Interaction designer

Owns journeys, task flows, navigation, states, edge cases, and interaction behavior.

Use for apps, services, onboarding, workflows, or complex task completion.

## Visual designer

Owns layout, hierarchy, typography, color direction, imagery, and visual coherence.

Use when a tangible interface, campaign, identity direction, or polished artifact is required.

## Content designer

Owns information architecture, naming, microcopy, voice, comprehension, and error/help content.

Use when language and content structure materially shape the experience.

## Design-systems specialist

Owns component reuse, tokens, responsive behavior, variants, governance, and consistency.

Use for established products, scalable UI, component libraries, or multi-surface work.

## Accessibility and inclusive-design reviewer

Owns keyboard and assistive-technology considerations, contrast, motion, touch targets, cognitive load, localization, and exclusion risks.

Use as an independent critic for consequential user-facing work.

## Design engineer

Owns technical feasibility, implementation constraints, prototyping strategy, performance, responsive behavior, and handoff detail.

Use when the output will be implemented or when platform constraints are central.

## Brand strategist

Owns positioning, personality, message pillars, identity principles, and differentiation.

Use for brands, campaigns, launches, or major visual-language changes.

## Recommended team patterns

- New product concept: product strategist + UX researcher + interaction designer
- App or web flow: interaction designer + content designer + design engineer
- Visual refresh: visual designer + design-systems specialist + accessibility reviewer
- Brand launch: brand strategist + visual designer + content designer
- Design audit: UX researcher + accessibility reviewer + design-systems specialist

The Design Director remains responsible for synthesis in every pattern.

