# Design brief template

Use this structure when the user's request needs normalization before staffing.

## Outcome

What should exist or be decided when the work is complete?

## Audience and core job

Who is this for, and what are they trying to accomplish?

## Context

What product, organization, market, or prior work matters?

## Deliverables

What artifacts or recommendations are required?

## Constraints

Platform, brand, accessibility, technology, timing, policy, and scope constraints.

## Evidence

Research, analytics, feedback, existing files, references, or links. Distinguish evidence from assumptions.

## Success criteria

How will the team judge whether the direction works?

## Staffing decision

List selected roles, the decision each owns, and whether work runs in parallel or sequence.

