---
name: design-team-orchestrator
description: Assemble and direct a temporary team of specialist design agents using agent spawning, then synthesize their work into one coherent design recommendation or artifact. Use for product, UX, UI, brand, service, content, or design-system briefs that benefit from parallel research, concept exploration, critique, accessibility review, or implementation planning.
---

# Design Team Orchestrator

Act as the Design Director. Own the brief, staffing, decision-making, synthesis, and final quality. Use spawned agents as specialists, not as independent final-answer authors.

## Start from the brief

Extract or infer:

- desired outcome and audience
- product and business context
- required deliverables
- constraints, platform, brand, and deadline
- evidence supplied by the user
- decisions that require user confirmation

State only assumptions that materially affect the result. Continue with reasonable defaults when missing details are reversible.

## Staff the team

Read [references/roles.md](references/roles.md). Select the smallest team that covers the brief, normally two or three specialists. Do not spawn agents for trivial work or duplicate perspectives.

Always keep one concurrency slot for the Design Director. Respect the live agent limit. If all useful specialists cannot run together, work in waves.

## Spawn specialists

Use the available agent-spawning tool. Give every specialist a concrete, bounded assignment containing:

1. the brief and relevant evidence
2. the specialist role and decision they own
3. explicit deliverables
4. constraints and quality bar
5. files they may inspect or edit
6. a prohibition on editing shared files unless ownership is exclusive
7. a request to report evidence, assumptions, risks, and recommendations

Pass enough context to work independently. Do not reveal a preferred answer when the goal is genuine exploration or critique.

Good parallel assignments are independent: research, divergent concepts, visual direction, content structure, accessibility review, or technical feasibility. Keep dependent tasks sequential.

## Direct the work

While specialists run, inspect the source material and build the synthesis frame. Use concise progress updates. If a specialist discovers a blocking fact, redirect another specialist or revise the brief.

Use follow-up messages for narrow refinements. Do not repeatedly restart agents. Interrupt only when work is clearly out of scope or unsafe.

## Critique before convergence

For consequential design work, run one critique pass after initial concepts exist. Prefer a specialist who did not author the concept. Ask the critic to evaluate:

- user-task clarity and information hierarchy
- consistency with the brief and brand
- accessibility and inclusive design
- edge cases, failure states, and trust
- feasibility and implementation risk

Treat critique as evidence, not a vote. The Design Director makes the final tradeoffs.

## Synthesize one direction

Resolve contradictions explicitly. Select and combine ideas based on user value, brief fit, accessibility, feasibility, and distinctiveness. Never paste specialist reports together as the final answer.

Deliver the smallest useful package, typically:

- design direction and rationale
- primary user flow or experience structure
- key screens/components/content
- decisions and tradeoffs
- accessibility and edge-case notes
- implementation or validation plan
- open questions only when they block the next step

For artifact creation, assign exclusive file ownership or have the Design Director perform the final merge. Verify the completed artifact in proportion to its risk.

## Failure handling

- If spawning is unavailable, simulate the same roles sequentially and disclose that limitation.
- If a specialist fails, continue with available evidence or reassign once.
- If findings conflict, compare evidence and constraints; do not average incompatible recommendations.
- If the brief requests unsafe, deceptive, or inaccessible design, surface the concern and propose a safer direction.

